package com.store.shopping.controllers;

public class ShoppingOrderController {
}
