package com.store.shopping.entities.enums;

public enum ShoppingCartEnum {
    R,
    A,
    S
}
