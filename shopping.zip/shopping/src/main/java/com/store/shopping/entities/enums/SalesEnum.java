package com.store.shopping.entities.enums;

public enum SalesEnum {
    S,
    P,
    F
}
