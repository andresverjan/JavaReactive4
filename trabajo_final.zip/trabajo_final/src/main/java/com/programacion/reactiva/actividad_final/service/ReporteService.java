package com.programacion.reactiva.actividad_final.service;

import org.springframework.stereotype.Service;

@Service
public class ReporteService {
}
